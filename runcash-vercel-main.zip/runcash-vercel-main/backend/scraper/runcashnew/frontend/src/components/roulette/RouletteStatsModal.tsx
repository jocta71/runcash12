// Reexporta o componente RouletteStatsModal da pasta principal
import RouletteStatsModal from '../RouletteStatsModal';
export default RouletteStatsModal; 